#include "GameObject.hpp"

GameObject::GameObject() {

}
GameObject::~GameObject() {

}
