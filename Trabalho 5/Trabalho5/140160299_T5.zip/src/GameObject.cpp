#include "GameObject.hpp"

GameObject::GameObject() {
    constuct();
}

GameObject::~GameObject() {

}

void GameObject::constuct() {

    rotation = 0.0;
}
