#!/bin/sh
ctags --recurse --exclude=CMakeFiles .
