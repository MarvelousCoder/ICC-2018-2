var searchData=
[
  ['changename',['changeName',['../class_controller_user.html#a5db82806beb1fe9467edc89405630716',1,'ControllerUser']]],
  ['changepass',['changePass',['../class_controller_user.html#ad733c6e9d4e48eb5c444e9db8a7bde7a',1,'ControllerUser']]]
];
