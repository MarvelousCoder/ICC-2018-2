var searchData=
[
  ['managestudents',['manageStudents',['../class_controller_admin.html#ab1dcae5df5ac7b4635af375b8e1e87d6',1,'ControllerAdmin']]],
  ['managesubjects',['manageSubjects',['../class_controller_admin.html#a470a0d03df35552c18055c8d2d50d96a',1,'ControllerAdmin']]],
  ['manageuserdata',['manageUserData',['../class_controller_user.html#a801b7c786a965e610a4e57842751e887',1,'ControllerUser']]],
  ['manageusersubjects',['manageUserSubjects',['../class_controller_user.html#a541ac2be094e6a913b46072cdfaa2e55',1,'ControllerUser']]]
];
