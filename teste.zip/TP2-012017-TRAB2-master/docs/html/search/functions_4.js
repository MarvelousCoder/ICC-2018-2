var searchData=
[
  ['removestudent',['removeStudent',['../class_controller_admin.html#a9d1196109e8c6d0a4e6406407628ea7a',1,'ControllerAdmin']]],
  ['removesubject',['removeSubject',['../class_controller_user.html#ac7369e11c1e15000c84c23b5029f81b2',1,'ControllerUser']]],
  ['requestauth',['requestAuth',['../class_controller_auth.html#a1ff74688e5a1c5e9ccb52267f8fc6547',1,'ControllerAuth']]]
];
