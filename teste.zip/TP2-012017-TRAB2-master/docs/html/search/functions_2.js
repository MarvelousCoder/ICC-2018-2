var searchData=
[
  ['includequiz',['includeQuiz',['../class_controller_admin.html#a700e99432c0d8e066bccafd229c69563',1,'ControllerAdmin']]],
  ['includestudent',['includeStudent',['../class_controller_admin.html#a320da22ffbff4cde3328b449b1f06be9',1,'ControllerAdmin']]],
  ['includesubject',['includeSubject',['../class_controller_admin.html#ab4082da8b8a9d050f1d4b0352e7f4258',1,'ControllerAdmin::includeSubject()'],['../class_controller_user.html#a255d7ae8dd73e9d1336f9ee5858474b1',1,'ControllerUser::includeSubject()']]],
  ['includetopic',['includeTopic',['../class_controller_admin.html#a5f4e8ee4ca02a04876659f83ffe99ca2',1,'ControllerAdmin']]]
];
