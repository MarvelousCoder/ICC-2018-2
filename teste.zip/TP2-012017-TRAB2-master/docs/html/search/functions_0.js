var searchData=
[
  ['authenticate',['authenticate',['../class_controller_auth.html#ad366ab80f5feff8adec15be7ac518d71',1,'ControllerAuth']]]
];
