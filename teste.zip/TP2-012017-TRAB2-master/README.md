Trabalho 2 da matéria de Técnicas de Programação 2

Universidade de Brasilia - UnB
Instituto de Ciencias Exatas - IE
Departamento de Ciencia da Computacao - CIC
Disciplina: Tecnicas de Programacao 2
Turma: A
Professora: Genaina Nunes Rodrigues
Alunos: Camila Pontes (15/0156120) e Vitor Bona (12/0138042)

Trabalho 2 - Implementacao do programa QuizTime - parte II conforme especificacoes disponibilizadas no moodle da disciplina.

Descricao: O QuizTime é um programa que permite ao usuario estudar diferentes topicos de diversas disciplinas respondendo a quizzes.
Durante o desenvolvimento do trabalho, o grupo buscou aplicar os conceitos de programacao sistematica vistos em sala de aula.

Contribuicoes:
Vitor - Entities, Managers, Loader/Writer
Camila - Arquitetura, Controllers, Roteiro de Teste

Instrucoes para compilacao:
Digitar o comando make na pasta do projeto.
